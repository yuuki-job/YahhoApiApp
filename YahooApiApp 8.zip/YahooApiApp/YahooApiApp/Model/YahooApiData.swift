//
//  YahooApiData.swift
//  YahooApiApp
//
//  Created by 徳永勇希 on 2020/10/27.
//  Copyright © 2020 yuuki. All rights reserved.
//

import Foundation
class YahooApiData {
    var name:String
    var adress:String
    var tellNumber:String
    var category:String
    var leadImage:String
    var catchCopy:String
    var rating:String
    var genre:String
    
    
    
    init(name:String,adress:String,tellNumber:String,category:String,leadImage:String,catchCopy:String,rating:String,genre:String) {
        self.name = name
        self.adress = adress
        self.tellNumber = tellNumber
        self.category = category
        self.leadImage = leadImage
        self.catchCopy = catchCopy
        self.rating = rating
        self.genre = genre
    }
}

